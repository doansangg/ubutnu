import { ServerConfigs } from './end_point.config';

export const AppConfigs = {
  ServerConfigs: ServerConfigs,
};
