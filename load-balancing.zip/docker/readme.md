sudo nano /etc/hosts
them dong duoi day vao /etc/hosts:
	127.0.1.1	lb.com

docker compose up

Truy cap: lb.com

