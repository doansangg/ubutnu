export const RouterLinks = {
  APP: '/app',
  BOOK_PAGE: '/app/book',
};
