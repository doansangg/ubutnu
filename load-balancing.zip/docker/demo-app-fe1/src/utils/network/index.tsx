import * as APIServices from './services'

export * from './services'

export const useAPI = () => {
    return APIServices
}